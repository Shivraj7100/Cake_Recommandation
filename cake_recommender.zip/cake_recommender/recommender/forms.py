from django import forms
from .models import CakePreference

class CakeForm(forms.ModelForm):
    class Meta:
        model = CakePreference
        fields = ['age', 'gender', 'diet', 'cake_type']
