from django.db import models

class CakePreference(models.Model):
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    diet = models.CharField(max_length=20)
    cake_type = models.CharField(max_length=20)
    recommendation = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.gender}, {self.diet} - {self.recommendation}"
