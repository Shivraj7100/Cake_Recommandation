from django.shortcuts import render
from django.http import JsonResponse
import pickle
import os
import numpy as np

# Load the trained ML model
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'recommender.pkl')

if os.path.exists(MODEL_PATH):
    with open(MODEL_PATH, 'rb') as model_file:
        model = pickle.load(model_file)
else:
    model = None

# Function to encode categorical values into numeric
def encode_input(age, gender, diet, cake_type):
    gender_map = {"Male": 0, "Female": 1, "Other": 2}
    diet_map = {"Vegetarian": 0, "Non-Vegetarian": 1, "Vegan": 2}
    cake_type_map = {"Birthday": 0, "Anniversary": 1}

    return [
        int(age),
        gender_map.get(gender, -1),  
        diet_map.get(diet, -1),      
        cake_type_map.get(cake_type, -1)
    ]

# Home Page View
def home(request):
    return render(request, 'index.html')

# Prediction View
def predict(request):
    if request.method == 'POST':
        try:
            # Extract values from the form
            age = request.POST.get('age')
            gender = request.POST.get('gender')
            diet = request.POST.get('diet')
            cake_type = request.POST.get('cake_type')

            # Validate input
            if not age or not gender or not diet or not cake_type:
                return JsonResponse({'error': 'Missing input fields'})

            # Convert inputs to numerical format
            input_data = np.array([encode_input(age, gender, diet, cake_type)]).reshape(1, -1)

            if model:
                prediction = model.predict(input_data)[0]  # Get prediction
            else:
                prediction = "Error: Model not loaded"

            return JsonResponse({'prediction': prediction})

        except Exception as e:
            return JsonResponse({'error': str(e)})

    return JsonResponse({'error': 'Invalid request'})
