from django.shortcuts import render
from django.http import JsonResponse
import pickle
import os

# Load the trained ML model
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'recommender.pkl')

if os.path.exists('recommender.pkl'):
    with open('recommender.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
else:
    model = None

def home(request):
    return render(request, 'index.html')

def predict(request):
    if request.method == 'POST':
        try:
            age = int(request.POST.get('age'))
            gender = request.POST.get('gender')
            diet = request.POST.get('diet')
            cake_type = request.POST.get('cake_type')

            # Convert categorical values into numerical ones (if required)
            input_data = [[age, gender, diet, cake_type]]

            if model:
                prediction = model.predict(input_data)[0]
            else:
                prediction = "Error: Model not loaded"

            return JsonResponse({'prediction': prediction})

        except Exception as e:
            return JsonResponse({'error': str(e)})

    return JsonResponse({'error': 'Invalid request'})
